USE AdventureWorksLT
GO

CREATE OR ALTER PROCEDURE [dbo].[testMigration] 
AS                              
BEGIN
        select top 5 * from SomeOtherDatabase.dbo.Customer
END
GO

CREATE OR ALTER PROCEDURE [dbo].[testCmdShell] 
AS                              
BEGIN
        Exec xp_cmdshell 'dir *.exe'
END
GO

CREATE OR ALTER PROCEDURE [dbo].[testMemoryOptimized]
AS 
BEGIN
CREATE TABLE dbo.migrationSales   
(  
   so_id INT NOT NULL PRIMARY KEY NONCLUSTERED,  
   cust_id INT NOT NULL,  
   so_date DATE NOT NULL INDEX ix_date NONCLUSTERED,  
   so_total MONEY NOT NULL
) WITH (MEMORY_OPTIMIZED=ON);
END