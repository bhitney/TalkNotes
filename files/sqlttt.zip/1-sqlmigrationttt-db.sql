USE [master]
GO

CREATE DATABASE [SomeOtherDatabase]
go

USE [SomeOtherDatabase]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Customer](
	[CustomerId] [uniqueidentifier] NOT NULL,
	[FirstName] [nvarchar](50) NULL,
	[LastName] [nvarchar](50) NULL
) ON [PRIMARY]
GO
INSERT [dbo].[Customer] ([CustomerId], [FirstName], [LastName]) VALUES (N'9d4ceca6-f708-48aa-80f3-e37a0ef88276', N'FirstName', N'LastName')
GO
ALTER TABLE [dbo].[Customer] ADD  CONSTRAINT [DF_Customer_CustomerId]  DEFAULT (newid()) FOR [CustomerId]
GO
USE [master]
GO
ALTER DATABASE [SomeOtherDatabase] SET  READ_WRITE 
GO
